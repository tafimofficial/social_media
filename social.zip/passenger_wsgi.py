from social_platform.wsgi import application

# cPanel's Passenger configuration requires the application to be named 'application'
# This file imports the WSGI application from the standard django wsgi.py
